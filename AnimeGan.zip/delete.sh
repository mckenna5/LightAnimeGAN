#!/bin/bash

cd /home/jay/AnimeGan/dataset/train_photo || { echo "路径不存在"; exit 1; }

for file in *.jpg; do
  # 提取数字部分（不含扩展名）
  num=${file%%.jpg}
  # 如果不是 0~1023，就删除
  if [ "$num" -lt 0 ] || [ "$num" -gt 1023 ]; then
    rm "$file"
  fi
done

echo "非 0.jpg~1023.jpg 的文件已删除。"
