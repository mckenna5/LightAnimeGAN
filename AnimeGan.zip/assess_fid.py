import subprocess
import os

def calculate_fid_with_pytorch_fid(path_to_real_images, path_to_generated_images, device='cuda', batch_size=50):
    """
    使用 pytorch-fid 命令行工具计算 FID 分数。

    参数:
    path_to_real_images (str): 真实目标风格图像文件夹的路径。
    path_to_generated_images (str): 模型生成的对应风格图像文件夹的路径。
    device (str): 计算设备 ('cuda' 或 'cpu')。
    batch_size (int): 处理图像的批次大小。

    返回:
    float: FID 分数，如果出错则返回 None。
    """
    if not os.path.exists(path_to_real_images):
        print(f"错误: 真实目标风格图像路径不存在: {path_to_real_images}")
        print("请确保此路径指向一个包含真实目标风格卡通图片（例如，真实宫崎骏风格图片）的文件夹。")
        return None
    if not os.path.exists(path_to_generated_images):
        print(f"错误: 生成图像路径不存在: {path_to_generated_images}")
        return None

    if not os.listdir(path_to_real_images):
        print(f"警告: 真实目标风格图像文件夹 '{path_to_real_images}' 为空。FID 计算需要图像。")
        return None
    if not os.listdir(path_to_generated_images):
        print(f"警告: 生成图像文件夹 '{path_to_generated_images}' 为空。FID 计算需要图像。")
        return None

    print(f"\n开始计算 FID 分数...")
    print(f"真实目标风格图像路径: {path_to_real_images}")
    print(f"生成图像路径: {path_to_generated_images}")
    print(f"使用设备: {device}")

    command = [
        'python', '-m', 'pytorch_fid',
        path_to_real_images,
        path_to_generated_images,
        '--device', device,
        '--batch-size', str(batch_size)
    ]

    try:
        process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, encoding='utf-8')
        stdout, stderr = process.communicate()

        if process.returncode == 0:
            try:
                # FID 分数通常是输出的最后一行或包含 "FID: " 的行
                fid_score_line = ""
                for line in stdout.strip().split('\n'):
                    if "FID: " in line:
                        fid_score_line = line
                        break
                if fid_score_line:
                    fid_score = float(fid_score_line.split("FID: ")[1].strip())
                    print(f"计算得到的 FID 分数: {fid_score:.4f} (越低越好)")
                    return fid_score
                else:
                    print("错误: 未能在输出中找到 FID 分数。")
                    print("STDOUT:")
                    print(stdout)
                    print("STDERR:")
                    print(stderr)
                    return None
            except Exception as e:
                print(f"解析 FID 输出时出错: {e}")
                print("STDOUT:")
                print(stdout)
                print("STDERR:")
                print(stderr)
                return None
        else:
            print(f"pytorch-fid 命令执行出错 (返回码: {process.returncode}):")
            print("STDOUT:")
            print(stdout)
            print("STDERR:")
            print(stderr)
            return None
    except FileNotFoundError:
        print("错误: 未找到 'python' 命令或 'pytorch_fid' 模块。请确保已正确安装并在 PATH 中。")
        return None
    except Exception as e:
        print(f"执行 FID 计算时发生未知错误: {e}")
        return None

if __name__ == '__main__':
    # --- 关键路径设置 ---
    # 1. 模型生成的宫崎骏风格图像文件夹 
    path_generated_hayao_style = '/home/lxj/code/results/Hayao--HR_photo'

    # 2. 真实的宫崎骏风格卡通图像文件夹 
    #    重要：这个路径不能是 'dataset/test/HR_photo' (原始照片)，
    #    而应该是一个包含大量真实宫崎骏风格卡通图片的文件夹。
    path_real_hayao_style_dataset = '/home/lxj/code/dataset/Hayao/style' 

    # --- 可选：其他风格的路径 ---
    # path_generated_shinkai_style = 'results/Shinkai--HR_photo'
    # path_real_shinkai_style_dataset = 'path/to/your/REAL_SHINKAI_STYLE_CARTOONS' 

    print("--- 计算宫崎骏风格的 FID ---")
    if "path/to/your" in path_real_hayao_style_dataset:
        print(f"请修改 'path_real_hayao_style_dataset' 为您真实的宫崎骏风格卡通图片数据集的路径。")
        print(f"当前路径为占位符: {path_real_hayao_style_dataset}")
    else:
        fid_value_hayao = calculate_fid_with_pytorch_fid(path_real_hayao_style_dataset, path_generated_hayao_style)
        if fid_value_hayao is not None:
            print(f"\n最终宫崎骏风格 FID: {fid_value_hayao:.4f}")
        else:
            print("\n未能计算宫崎骏风格的 FID。")

    # 计算其他风格的FID，可以取消注释并修改以下部分：
    # print("\n--- 计算新海诚风格的 FID ---")
    # if "path/to/your" in path_real_shinkai_style_dataset:
    #     print(f"请修改 'path_real_shinkai_style_dataset' 为您真实的新海诚风格卡通图片数据集的路径。")
    #     print(f"当前路径为占位符: {path_real_shinkai_style_dataset}")
    # else:
    #     if os.path.exists(path_generated_shinkai_style): # 检查生成的文件夹是否存在
    #         fid_value_shinkai = calculate_fid_with_pytorch_fid(path_real_shinkai_style_dataset, path_generated_shinkai_style)
    #         if fid_value_shinkai is not None:
    #             print(f"\n最终新海诚风格 FID: {fid_value_shinkai:.4f}")
    #         else:
    #             print("\n未能计算新海诚风格的 FID。")
    #     else:
    #         print(f"未找到生成的新海诚风格图像文件夹: {path_generated_shinkai_style}")