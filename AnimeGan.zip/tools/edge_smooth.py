import sys
import os
import numpy as np
import cv2
import argparse
from glob import glob
from tqdm import tqdm

# 获取项目根目录（tools 的父目录）
project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
sys.path.append(project_root)
from tools.utils import check_folder

def parse_args():
    desc = "Edge smoothed"
    parser = argparse.ArgumentParser(description=desc)
    # parser.add_argument('--dataset', type=str, default='Hayao', help='dataset_name')
    parser.add_argument('--dataset', type=str, default='Shinkai', help='dataset_name')
    parser.add_argument('--img_size', type=int, default=256, help='The size of image')
    return parser.parse_args()

def make_edge_smooth(dataset_name, img_size):
    dataset_root = os.path.join(project_root, 'dataset', dataset_name)
    style_dir = os.path.join(dataset_root, 'style')
    smooth_dir = os.path.join(dataset_root, 'smooth')

    check_folder(smooth_dir)

    file_list = glob(os.path.join(style_dir, '*.jpg')) + glob(os.path.join(style_dir, '*.png'))

    kernel_size = 5
    kernel = np.ones((kernel_size, kernel_size), np.uint8)
    gauss = cv2.getGaussianKernel(kernel_size, 0)
    gauss = gauss * gauss.transpose(1, 0)

    for f in tqdm(file_list, desc="Edge smoothing"):
        file_name = os.path.basename(f)
        bgr_img = cv2.imread(f)
        gray_img = cv2.imread(f, 0)
        bgr_img = cv2.resize(bgr_img, (img_size, img_size))
        pad_img = np.pad(bgr_img, ((2, 2), (2, 2), (0, 0)), mode='reflect')
        gray_img = cv2.resize(gray_img, (img_size, img_size))
        edges = cv2.Canny(gray_img, 100, 200)
        dilation = cv2.dilate(edges, kernel)
        gauss_img = np.copy(bgr_img)
        idx = np.where(dilation != 0)
        for i in range(len(idx[0])):
            y, x = idx[0][i], idx[1][i]
            for c in range(3):
                gauss_img[y, x, c] = np.sum(
                    np.multiply(pad_img[y:y+kernel_size, x:x+kernel_size, c], gauss))
        cv2.imwrite(os.path.join(smooth_dir, file_name), gauss_img)

def main():
    args = parse_args()
    make_edge_smooth(args.dataset, args.img_size)

if __name__ == '__main__':
    main()
