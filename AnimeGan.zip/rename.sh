#!/bin/bash

# 切换到目标目录
cd /home/jay/AnimeGan/dataset/train_photo || { echo "路径不存在"; exit 1; }

i=1

# 第一步：临时添加前缀，避免重名冲突（处理 jpg 和 png）
for file in *.jpg *.png; do
  [ -e "$file" ] || continue  # 跳过不存在的扩展名
  mv "$file" "temp_$i.${file##*.}"
  i=$((i + 1))
done

# 第二步：统一重命名为 1.jpg, 2.jpg, ...，不管原来是 png 还是 jpg
i=1
for file in temp_*; do
  mv "$file" "$i.jpg"
  i=$((i + 1))
done

echo "图片已安全重命名完成！所有图片统一为 .jpg"
