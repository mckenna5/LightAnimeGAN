from flask import Flask, request, jsonify
import os
import subprocess
import time

app = Flask(__name__, static_folder='/home/jay/AnimeGan', static_url_path='')

# 上传目录
UPLOAD_DIR = '/home/jay/AnimeGan/web/uploads/'
os.makedirs(UPLOAD_DIR, exist_ok=True)

@app.route('/')
def serve_index():
    return app.send_static_file('web/index.html')

@app.route('/api/generate', methods=['POST'])
def generate():
    try:
        if 'photo' not in request.files:
            return jsonify({'success': False, 'message': 'No photo uploaded'}), 400

        photo = request.files['photo']
        if not photo.filename.lower().endswith(('.jpg', '.jpeg', '.png')):
            return jsonify({'success': False, 'message': 'Unsupported file format'}), 400

        # 获取风格参数，默认为 Hayao
        style_name = request.form.get('style_name', 'Hayao')
        if style_name not in ['Hayao', 'Shinkai']:
            return jsonify({'success': False, 'message': 'Invalid style name'}), 400

        # 根据风格选择权重和结果目录
        checkpoint_dir = f'/home/jay/AnimeGan/checkpoint/generator_{style_name}_weight/'
        result_dir = f'/home/jay/AnimeGan/results/{style_name}--uploads/'
        os.makedirs(result_dir, exist_ok=True)

        # 保存上传的图片
        photo_path = os.path.join(UPLOAD_DIR, photo.filename)
        print(f"Saving uploaded photo to: {photo_path}")
        photo.save(photo_path)

        # 调用 test.py 进行推理
        start_time = time.time()
        cmd = [
            'python', '/home/jay/AnimeGan/test.py',
            '--checkpoint_dir', checkpoint_dir,
            '--test_dir', UPLOAD_DIR,
            '--style_name', style_name,
            '--if_adjust_brightness', 'False'
        ]
        print(f"Running command: {' '.join(cmd)}")
        result = subprocess.run(cmd, capture_output=True, text=True, cwd='/home/jay/AnimeGan/')
        print(f"test.py stdout: {result.stdout}")
        print(f"test.py stderr: {result.stderr}")

        # 检查推理是否成功
        generated_path = os.path.join(result_dir, photo.filename)
        print(f"Checking for generated image: {generated_path}")
        if os.path.exists(generated_path):
            end_time = time.time()
            print(f"Generated image found: {generated_path}")
            return jsonify({
                'success': True,
                'generated_url': f'/results/{style_name}--uploads/{photo.filename}',
                'time': round(end_time - start_time, 2)
            })
        else:
            print(f"Generated image not found: {generated_path}")
            return jsonify({
                'success': False,
                'message': 'Generation failed',
                'error': result.stderr
            }), 500

    except Exception as e:
        print(f"Error in /api/generate: {str(e)}")
        return jsonify({
            'success': False,
            'message': 'Server error',
            'error': str(e)
        }), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)